package CPManagement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ccslearner
 */

import java.sql.*;
import java.util.*;

public class Location {

    public int location_id;
    public String locname;
    public String opentime;
    public String closetime;

    public ArrayList<Integer> location_idlist = new ArrayList<>();
    public ArrayList<String> locnamelist = new ArrayList<>();
    public ArrayList<String> opentimelist = new ArrayList<>();
    public ArrayList<String> closetimelist = new ArrayList<>();

    public Location() {
    }
    
    public List<CPReport1> generateCampusPassReport1() {
        List<CPReport1> report = new ArrayList<>();

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/G11DBAPP?user=root&password=12345678&useTimezone=true&serverTimezone=UTC&useSSL=false");
            System.out.println("Connection successful");

             PreparedStatement pstmt = conn.prepareStatement("SELECT locname, COUNT(campuspasslogs.log_id) AS total_issued, SUM(CASE WHEN datetime_return IS NOT NULL THEN 1 ELSE 0 END) AS total_returned FROM location LEFT JOIN campuspasslogs ON location.location_id = campuspasslogs.location_id GROUP BY locname");
            ResultSet rs = pstmt.executeQuery();
        
            while (rs.next()) {
                String buildingName = rs.getString("locname");
                int totalIssued = rs.getInt("total_issued");
                int totalReturned = rs.getInt("total_returned");
                double percentageReturned = (totalIssued == 0) ? 0 : ((double) totalReturned / totalIssued) * 100;

                CPReport1 entry = new CPReport1(buildingName, totalIssued, totalReturned, percentageReturned);
                report.add(entry);
            }

            rs.close();
            pstmt.close();
            conn.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return report;
    }
    
   public List<Location> filter_location() {
    List<Location> filteredResults = new ArrayList<>();

    try {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/G11DBAPP?user=root&password=12345678&useTimezone=true&serverTimezone=UTC&useSSL=false");
        System.out.println("Connection successful");

        StringBuilder query = new StringBuilder("SELECT * FROM location WHERE 1=1");

        if (opentime != null && !opentime.isEmpty()) {
            query.append(" AND opentime = '").append(opentime).append("'");
        }

        if (closetime != null && !closetime.isEmpty()) {
            query.append(" AND closetime = '").append(closetime).append("'");
        }

        PreparedStatement pstmt = conn.prepareStatement(query.toString());
        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            Location result = new Location();
            result.location_id = rs.getInt("location_id");
            result.locname = rs.getString("locname");
            result.opentime = rs.getString("opentime");
            result.closetime = rs.getString("closetime");
            filteredResults.add(result);
        }

        rs.close();
        pstmt.close();
        conn.close();

    } catch (Exception e) {
        System.out.println(e.getMessage());
    }

    return filteredResults;
}



    
    public List<Location> search_location() {
    List<Location> searchResults = new ArrayList<>();

    try {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/G11DBAPP?user=root&password=12345678&useTimezone=true&serverTimezone=UTC&useSSL=false");
        System.out.println("Connection successful");

        StringBuilder query = new StringBuilder("SELECT * FROM location WHERE 1=1");

        if (location_id != 0) {
            query.append(" AND location_id = ").append(location_id);
        }

        if (locname != null && !locname.isEmpty()) {
            query.append(" AND locname LIKE '%").append(locname).append("%'");
        }

        PreparedStatement pstmt = conn.prepareStatement(query.toString());
        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            Location result = new Location();
            result.location_id = rs.getInt("location_id");
            result.locname = rs.getString("locname");
            result.opentime = rs.getString("opentime");
            result.closetime = rs.getString("closetime");
            searchResults.add(result);
        }

        rs.close();
        pstmt.close();
        conn.close();

    } catch (Exception e) {
        System.out.println(e.getMessage());
    }

    return searchResults;
}

    
    public int update_location() {
        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/G11DBAPP?user=root&password=12345678&useTimezone=true&serverTimezone=UTC&useSSL=false");
            System.out.println("Connection successful");

            PreparedStatement pstmt = conn.prepareStatement("UPDATE location SET locname=?, opentime=?, closetime=? WHERE location_id=?");
            pstmt.setString(1, locname);
            pstmt.setString(2, opentime);
            pstmt.setString(3, closetime);
            pstmt.setInt(4, location_id);

            int rowsAffected = pstmt.executeUpdate();

            pstmt.close();
            conn.close();

            return rowsAffected > 0 ? 1 : 0; // Return 1 if at least one row was updated

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public int delete_location() {

    try {
        Connection conn;
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/G11DBAPP?user=root&password=12345678&useTimezone=true&serverTimezone=UTC&useSSL=false");
        System.out.println("Connection successful");

        // Check if the location with the specified ID exists
        PreparedStatement checkStmt = conn.prepareStatement("SELECT location_id FROM location WHERE location_id = ?");
        checkStmt.setInt(1, location_id);
        ResultSet checkResult = checkStmt.executeQuery();

        if (!checkResult.next()) {
            // Location with the specified ID does not exist
            System.out.println("Location with ID " + location_id + " does not exist.");
            return 0;
        }

        // Location exists, proceed with deletion
        PreparedStatement deleteStmt = conn.prepareStatement("DELETE FROM location WHERE location_id = ?");
        deleteStmt.setInt(1, location_id);
        deleteStmt.executeUpdate();

        System.out.println("Location with ID " + location_id + " deleted successfully.");
        return 1;

    } catch (SQLException e) {
        System.out.println("Error: " + e.getMessage());
        return 0;
    }
}
    
    
    public int add_location() {

        try {
            Connection conn;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/G11DBAPP?user=root&password=12345678&useTimezone=true&serverTimezone=UTC&useSSL=false");
            System.out.println("Connection successful");

            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(location_id) + 1 AS newID FROM location");
            ResultSet rst = pstmt.executeQuery();
            while (rst.next()) {
                location_id = rst.getInt("newID");
            }

            pstmt = conn.prepareStatement("INSERT into location (location_id, locname, opentime, closetime) VALUES(?,?,?,?)");
            pstmt.setInt(1, location_id);
            pstmt.setString(2, locname);
            pstmt.setString(3, opentime);
            pstmt.setString(4, closetime);
            pstmt.executeUpdate();

            pstmt.close();
            conn.close();
            return 1;

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public static void main(String args[]) {
        
        Location A = new Location(); 
        A.delete_location(); 
    }
}
