/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ccslearner
 */
package CPManagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CampusPassRequest {

    public static int addStudentAndRequest(String student_id, String lastname, String firstname, String middlename,
            String college, String mobilenum, String emailaddress, String location_id, String reason) {

        int status = 0;
        int request_id = 0;

        try {
            
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/G11DBAPP?user=root&password=12345678&useTimezone=true&serverTimezone=UTC&useSSL=false");
            System.out.println("Connection successful");

            String insertStudentQuery = "INSERT INTO student (student_id, lastname, firstname, middlename, college, mobilenum, emailaddress) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement studentStmt = conn.prepareStatement(insertStudentQuery);
            studentStmt.setString(1, student_id);
            studentStmt.setString(2, lastname);
            studentStmt.setString(3, firstname);
            studentStmt.setString(4, middlename);
            studentStmt.setString(5, college);
            studentStmt.setString(6, mobilenum);
            studentStmt.setString(7, emailaddress);
            status = studentStmt.executeUpdate();

            PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(request_id) + 1 AS newID FROM passrequest");
            ResultSet rst = pstmt.executeQuery();
            while (rst.next()) {
                request_id = rst.getInt("newID");
            }

            String insertRequestQuery = "INSERT INTO passrequest (request_id, student_id, location_id, reason, request_datetime) VALUES (?, ?, ?, ?, NOW())";
            PreparedStatement requestStmt = conn.prepareStatement(insertRequestQuery);
            requestStmt.setInt(1, request_id);
            requestStmt.setString(2, student_id);
            requestStmt.setString(3, location_id);
            requestStmt.setString(4, reason);
            status = requestStmt.executeUpdate();

            studentStmt.close();
            requestStmt.close();
            pstmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }
}
