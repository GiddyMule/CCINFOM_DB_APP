package CPManagement;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ccslearner
 */
public class CPReport1 {
    
    private String buildingName;
    private int totalIssued;
    private int totalReturned;
    private double percentageReturned;

    public CPReport1(String buildingName, int totalIssued, int totalReturned, double percentageReturned) {
        this.buildingName = buildingName;
        this.totalIssued = totalIssued;
        this.totalReturned = totalReturned;
        this.percentageReturned = percentageReturned;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public int getTotalIssued() {
        return totalIssued;
    }

    public int getTotalReturned() {
        return totalReturned;
    }

    public double getPercentageReturned() {
        return percentageReturned;
    }
}

